#
## Author: Daniel Scholnick
## Purpose: Poster 
## IST 719
#

library(readxl)
library(ggplot2)
library(ggalt)
library(ggthemes)
library(rworldmap)
library(plotly)
library(treemapify)
library(RColorBrewer)


#Load file
file <- read.csv(file = "/Users/dscholnick/Documents/MiDS/IST719/world_data.csv"
                 , header = TRUE
                 , stringsAsFactors = FALSE
                 , strip.white = TRUE)  


## World_factbook file edited in excel locally
file2 <- read_excel("/Users/dscholnick/Documents/MiDS/IST719/Pop_world_2018.xls")
pop <- as.data.frame(file2)
str(pop)

###################
#Exploring, preparing and cleaning data
###################

#check out data
View(pop)
View(file)
str(file)
colnames(file)

#change population to numeric
pop$population <- as.numeric(as.character(pop$population))


#Change column names
colnames(file) <- c("country", "region", "population", "area (sq.mi)"
                            , "pop.density (sq.mi)", "coastline.ratio", "net.migration"
                            , "infant.mortality.rate.1000.births", "GDP.per.capita"
                            , "literacy.rate", "phones.per.1000", "arable.land", "crops"
                            , "other", "climate.type", "birth.rate.per.1000"
                            , "death.rate.per.1000", "labor.agriculture"
                            , "labor.industry", "labor.service")

#remove "other" and "population" variable
file <- file[,c(1:2, 4:13, 15:20)]

#merge and add in new population from world factbook 2017
world <- merge(file, pop, by=c("country", "country"))
as.numeric(as.character(world$population))
#View results
str(world)

#research regions
unique(file$region)

#Add new column named regions and change geographic regions
regions <- world$region
world <- data.frame(world, regions)
as.character(world$regions)

#reorder columns
world <- world[c(1, 20 ,2 ,19, 3:18)]

#adjust regions names
world$regions = gsub("NORTHERN AFRICA", "Africa", world$regions)
world$regions = gsub("SUB-SAHARAN AFRICA", "Africa", world$regions)
#world$regions = gsub("ASIA (EX. NEAR EAST)", "Asia", world$regions) # would not work
world$regions = gsub("C.W. OF IND. STATES", "Asia", world$regions)
world$regions = gsub("NEAR EAST", "Middle East", world$regions)
world$regions = gsub("WESTERN EUROPE", "Western Europe", world$regions)
world$regions = gsub("EASTERN EUROPE", "Eastern Europe", world$regions)
world$regions = gsub("NORTHERN AMERICA", "North America", world$regions)
world$regions = gsub("LATIN AMER. & CARIB", "South America", world$regions)
world$regions = gsub("OCEANIA", "Oceania", world$regions)
world$regions = gsub("BALTICS", "Baltics", world$regions)
world$regions <- replace(as.character(world$regions)
                         , world$regions == "ASIA (EX. Middle East)", "Asia")

#Mexico to North America
subset(world, country == "Mexico")

world[133,2] = "North America"
#create central america
world[c(21, 49, 62, 85, 90, 148, 156), 2] = "Central America"

#Iran to Middle.East
world[97, 2] = "Middle East"

#Create Carribean Region
world[c(7,8,11,15,18,29,39,52,57,58,82,83,89,102, 129, 145, 173), 2] = "Caribbean"

#check results
unique(world$regions)

####Prepare data for maps

#library(mapproj)
world_map <- map_data("world")
str(world_map)
world$country[world$country == "United States"] = "USA"
world$country[world$country == "Antigua & Barbuda"] = "Antigua"
world$country[world$country == "Bahamas, The"] = "Bahamas"
world$country[world$country == "Central African Rep."] = "Central African Republic"
world$country[world$country == "Congo, Repub. of the"] = "Republic of Congo"
world$country[world$country == "Korea, North"] = "North Korea"
world$country[world$country == "Korea, South"] = "South Korea"
world$country[world$country == "Micronesia, Fed. St."] = "Micronesia"
world$country[world$country == "N. Mariana Islands"] = "Northern Mariana Islands"
world$country[world$country == "Gambia, The"] = "Northern Mariana Islands"
world$country[world$country == "Congo, Dem. Rep."] = "Democratic Republic of the Congo"
world$country[world$country == "United Kingdom"] = "UK"
#compare country names
# table(world$country)
# table(world_map$region)

#merge dfs
world_map <- merge(world_map, world, by.x = "region", by.y = "country" )
#reorder data
world_map <- world_map[order(world_map$group, world_map$order),]

###########
## MAP
###########


#######literacy rate map 
gg_lit <- ggplot()
#gg_lit <- gg_lit + coord_map(xlim=c(-180,180), ylim = c(-60, 90)) 
gg_lit <- gg_lit + geom_map(data=world_map, map=world_map, aes(map_id=region, x=long, y=lat, fill= literacy.rate), color = "white")
gg_lit <- gg_lit + ggtitle("Literacy rate by country") 
#gg_lit <- gg_lit + theme(axis.ticks = element_blank(), axis.text = element_blank(), axis.title.x = element_blank()
                         # , axis.title.y = element_blank(),   panel.grid.major = element_blank(), panel.grid.minor = element_blank()
                         # ,panel.background = element_rect( colour = "Black",
                         #                                  size = 2, linetype = "solid"))
gg_lit <- gg_lit + theme(axis.ticks = element_blank(), axis.text = element_blank(), axis.title.x = element_blank(), axis.title.y = element_blank()
                         ,panel.grid.major = element_line(colour = "grey"))
gg_lit <- gg_lit + scale_fill_gradient(name= "literacy rate", low = "#FF0000", high = "#0066CC")
gg_lit <- gg_lit + coord_proj("+proj=robin +lon_0=0 +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84")
gg_lit <- gg_lit + theme_map(panel.background = element_rect())
gg_lit 


###########
## Visualizations
###########


######set colors for regions
pal <- c("#663333", "darkgreen", "#f5dfab", "blue", "#fa8100", "red" , "purple","#FF33FF" , "#00ccff", "yellow","green")

#######Boxplot of literacy by regions
box_lit_reg <- ggplot(world)
box_lit_reg <- box_lit_reg + aes(regions, literacy.rate)
box_lit_reg <- box_lit_reg + geom_boxplot(color = pal, fill = pal, lwd = .65, outlier.size = 2) 
box_lit_reg <- box_lit_reg + theme(axis.text.x = element_text(angle = 60, hjust = 1), panel.background = element_rect(fill = "gray75"))
box_lit_reg <- box_lit_reg + ggtitle("Literacy rate by region")
box_lit_reg <- box_lit_reg + ylim(0,100)
box_lit_reg


######create barplot of literacy by country for bottom 10%

#create df of bottom ten countries based on literacy by subsetting
lit_bot <- head(world[order(world$literacy.rate),],.1*nrow(world))

#create df of bottom ten countries based on birth rate per 1000
br_bot <- tail(world[order(world$birth.rate..per.1000.),],.1*nrow(world))

#use stat = identity will mean there is no tabling, everything is one to one

BP_LitBot <- ggplot(lit_bot) +
  aes(x = reorder(country, literacy.rate), y = literacy.rate, fill =regions) +
  scale_fill_manual(values = c("#663333", "darkgreen", "purple")) +
  geom_bar(aes(reorder(country,literacy.rate),literacy.rate),stat = "identity") +
  coord_flip() +
  ggtitle("Countries with the lowest literacy rate") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()
        ,panel.background = element_blank(), axis.title.y = element_blank(), axis.text.y = element_blank()
        , axis.ticks.y = element_blank(), axis.text.x = element_blank()
        , axis.title.x = element_blank(), axis.ticks.x = element_blank(), axis.line.x = element_blank()) +
  geom_text(aes(label = paste0(literacy.rate, " %")), color = "red", fontface = "bold", size = 4
            ,position=position_stack(vjust = 1.05) ) +
  geom_text(aes(label = country), color = "white", size = 4, 
            fontface = "bold", position = position_stack(vjust = 0.5)) 
  ylim(0,100) + scale_y_continuous(limit = c(0,100))
BP_LitBot

# Find mean of world literacy rate
mean(world$literacy.rate) # 83.2 %


#####ggplot scatterplot of literacy vs. imr with regions (Is there a correlation between literacy rate and imr?)
ggplot(world) +
  aes(x= infant.mortality.rate.1000.births, y = literacy.rate, col = regions) + 
  geom_point(size = 2) + 
  scale_color_manual(values = pal) +
  stat_smooth(method = "lm", col = "blue3") +
  theme(panel.background = element_rect(fill="gray75")) +
  ggtitle( "Literacy vs Infant Mortality Rate") +
  ylim(0,100) 



#####ggplot scatterplot of literacy vs. br with regions 
ggplot(world) +
  aes(x= birth.rate.per.1000, y = literacy.rate, col = regions) + 
  geom_point(size = 2)  + scale_color_manual(values = pal) +
  stat_smooth(method = "lm", col = "blue3") +
  theme(panel.background = element_rect(fill="gray75")) +
  ggtitle( "Literacy vs Birth Rate")+
  ylim(0,100) 


 
#####ggplot scatterplot of literacy vs. GDP with regions 
ggplot(world) +
  aes(x= GDP.per.capita, y = literacy.rate, col = regions) + 
  geom_point(size = 2) +
  scale_color_manual(values = pal) +
  stat_smooth(method = "lm", col = "blue3") +
  theme(panel.background = element_rect(fill="gray75")) +
  ggtitle( "Literacy vs GDP per Capita") +
  ylim(0,100) 
  

#####calculate total population of people living in countries with literacy rate above/below 85%
w <- which(tM$literacy.rate == "(85,100]")
pop_high_lit<- tM[c(3,6,7, 10, 12, 13, 16, 17, 20, 22, 23),]
#above
above <- sum(pop_high_lit$population)
#4293111374
#below
below <- sum(world$population) - above
#3115602937


#####Pie chart of literacy/illiteracy

#calculate total number of people who are literate and illiterate
pop_lit <- sum(world$population * (world$literacy.rate/100))
pop_no_lit <- sum(world$population) - pop_lit

#calculate percentage of illiterate
pop_no_lit/sum(world$population)

#add commas to total population
pop_lit_pretty <- prettyNum(sum(world$population),big.mark=",")

#create the pie chart
library(plotrix)
slices <- c(pop_lit, pop_no_lit)
lbls <- c("literate 78.3% ", "illiterate 21.7%")
pie3D(slices,labels=lbls,explode=0.2, col = c("blue", "red"),
      height = .05,
      main="Global literacy")


##### Tree map of literacy by country divided into regions with chosen literacy ranges 

#create bins
breaks <- c(10, 55, 85, 100)

#aggregate data
tM <- aggregate(world$population, list((world$literacy.rate = cut(world$literacy.rate, breaks, include.lowest = T)), world$regions), sum)

#add colnames
colnames(tM) <- c("literacy.rate", "region", "population")

#TM_plot <- ggplot(tM, aes(area = population, fill = literacy.rate , label= prettyNum(tM$population,big.mark=",")
TM_plot <- ggplot(tM, aes(area = population, fill = literacy.rate , label= region                         
              , subgroup = literacy.rate)) + geom_treemap() +
  scale_fill_brewer(palette = "Blues") +
  geom_treemap_subgroup_border(colour="white") +
  geom_treemap_text(fontface = "italic",
                    colour = "black",
                    place = "centre",
                    grow = F,
                    reflow=T) +
  labs(title="Global Population divided by country and literacy rate")
TM_plot




##### Other tools
# garbage cleanout  
# gc()
# # #rm(list = ls())
# # #restart Session
# .rs.restartR()
