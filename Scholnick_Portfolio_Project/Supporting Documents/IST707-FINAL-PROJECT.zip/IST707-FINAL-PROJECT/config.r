library(nflscrapR)
data("nflteams")


# apply scoring
pass.yd <- 0.2
pass.td <- 4
pick <- -2
rush.yd <- 0.1
rec.yd <- 0.1
td <- 6
two <- 2
fum <- -2

